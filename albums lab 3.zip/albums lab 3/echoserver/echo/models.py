from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager



class CustomUserManager(UserManager):
    def create_superuser(self, username, email=None, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('role', 'admin')  # Устанавливаем роль admin для суперпользователя

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(username, email, password, **extra_fields)


class CustomUser(AbstractUser):
    ROLES = (
        ('user', 'Обычный пользователь'),
        ('admin', 'Администратор'),
    )
    email = models.EmailField(unique=True)
    role = models.CharField(max_length=10, choices=ROLES, default='user')

    objects = CustomUserManager()  # Используем кастомный менеджер

    class Meta:
        db_table = 'echo_customuser'


class Album(models.Model):
    artist = models.CharField(max_length=100, verbose_name="Исполнитель")
    title = models.CharField(max_length=200, verbose_name="Название альбома")
    price = models.DecimalField(max_digits=6, decimal_places=2, verbose_name="Цена")
    release_year = models.IntegerField(verbose_name="Год выпуска")

    def __str__(self):
        return f"{self.artist} - {self.title} ({self.release_year})"

    class Meta:
        verbose_name = "Альбом"
        verbose_name_plural = "Альбомы"
