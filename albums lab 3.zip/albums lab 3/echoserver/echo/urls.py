from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView

urlpatterns = [
    # Основные маршруты
    path('', views.album_list, name='album_list'),
    path('new/', views.album_new, name='album_new'),
    path('<int:pk>/edit/', views.album_edit, name='album_edit'),
    path('<int:pk>/delete/', views.album_delete, name='album_delete'),

    # Маршруты аутентификации БЕЗ ПРЕФИКСА accounts/
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', LogoutView.as_view(next_page='album_list'), name='logout'),
]