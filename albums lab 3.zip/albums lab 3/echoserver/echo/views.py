from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from .models import Album, CustomUser
from .forms import AlbumForm, CustomUserCreationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.views.decorators.http import require_POST
from django.contrib.auth.forms import AuthenticationForm


def is_admin(user):
    # Проверяем как стандартные права суперпользователя, так и нашу кастомную роль
    return user.is_authenticated and (user.role == 'admin' or user.is_superuser)


def album_list(request):
    albums = Album.objects.all().order_by('artist', 'title')
    paginator = Paginator(albums, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'albums/album_list.html', {
        'page_obj': page_obj,
        'user': request.user
    })


@login_required
def album_new(request):
    if request.method == "POST":
        form = AlbumForm(request.POST)
        if form.is_valid():
            album = form.save()
            messages.success(request, f'Альбом "{album.title}" успешно добавлен')
            return redirect('album_list')
    else:
        form = AlbumForm()

    return render(request, 'albums/album_edit.html', {
        'form': form,
        'title': 'Новый альбом'
    })


@user_passes_test(is_admin)
def album_edit(request, pk):
    album = get_object_or_404(Album, pk=pk)
    if request.method == "POST":
        form = AlbumForm(request.POST, instance=album)
        if form.is_valid():
            form.save()
            messages.success(request, f'Альбом "{album.title}" успешно обновлен')
            return redirect('album_list')
    else:
        form = AlbumForm(instance=album)

    return render(request, 'albums/album_edit.html', {
        'form': form,
        'title': f'Редактирование: {album.title}'
    })


@user_passes_test(is_admin)
def album_delete(request, pk):
    album = get_object_or_404(Album, pk=pk)
    if request.method == "POST":
        title = album.title
        album.delete()
        messages.success(request, f'Альбом "{title}" успешно удален')
        return redirect('album_list')

    return render(request, 'albums/album_confirm_delete.html', {'album': album})


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Регистрация прошла успешно!')
            return redirect('album_list')
    else:
        form = CustomUserCreationForm()

    return render(request, 'registration/register.html', {
        'form': form,
        'title': 'Регистрация'
    })


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Добро пожаловать, {username}!')
                return redirect('album_list')
        else:
            messages.error(request, 'Неверное имя пользователя или пароль')
    else:
        form = AuthenticationForm()

    return render(request, 'registration/login.html', {
        'form': form,
        'title': 'Вход в систему'
    })


@require_POST
def logout_view(request):
    if request.user.is_authenticated:
        logout(request)
        messages.success(request, 'Вы успешно вышли из системы')
    return redirect('album_list')



