from django.urls import path

from . import views

urlpatterns = [
    path('', views.album_list, name='album_list'),
    path('new/', views.album_new, name='album_new'),
    path('<int:pk>/edit/', views.album_edit, name='album_edit'),
    path('<int:pk>/delete/', views.album_delete, name='album_delete'),
]