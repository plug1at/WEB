from django.db import models

class Album(models.Model):
    artist = models.CharField(max_length=100, verbose_name="Исполнитель")
    title = models.CharField(max_length=200, verbose_name="Название альбома")
    price = models.DecimalField(max_digits=6, decimal_places=2, verbose_name="Цена")
    release_year = models.IntegerField(verbose_name="Год выпуска")

    def __str__(self):
        return f"{self.artist} - {self.title} ({self.release_year})"

    class Meta:
        verbose_name = "Альбом"
        verbose_name_plural = "Альбомы"
